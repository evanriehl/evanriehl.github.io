DATA AND SIMULATION CODES
"Accountability, test prep incentives, and the design of math and English exams"
by Evan Riehl and Meredith Welch

This zip file includes:

 1. raw_data/: Stata datasets with the raw data that we extracted from the technical reports for each exam in our main sample

 2. results/: The datasets that result from our simulations, which we use for our main results (Tables 2-4)

 3. code/: Stata codes that run our simulations and replicate Tables 2-4
   - 1-run-simulations.do: Runs the simulations for all six states
     * This uses the codes fl-simulate.do, ..., tx-simulate.do, and collapse-data.do
   - 2-make-tables.do: Reproduces our main results

